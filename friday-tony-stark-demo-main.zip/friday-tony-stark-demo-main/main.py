def main():
    print("Hello from friday-shaikh-arman-demo!")


if __name__ == "__main__":
    main()
